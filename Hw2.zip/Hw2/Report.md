For this assignment, all the needed images can be found in the images folder and then in the subfolder matching the question number. Similarly all the saved states can be found in the saved states folder. Lastly the code for part 3 can be found in the Code folder.

Part 1: Scalar Field Visualization

Question 1.

A. The data type that gets assigned is polygon mesh. You can find that on the information panel. Some advantages to polygonal meshesare they are widely used, they can be processed quickly, and they can be easily modified however, they also are just approximations of the actuall surface and as such are less accurate and they also typically have a larger file size.

Question 2.

A. The assigned datatype is Image (Uniform Rectilinear Grid).

C. I looked at the values in the color map first and set the iso value to about what the color map had and then played with the values untill it looked good.

Question 3.
A. I could not figure out how to change the iso value, but because the liver voxels have a value of 255 you can just use 255.

C. The density of air is about 1.225 kg/m^3, soft tissue has a density of about 900 to 1100 kg/m^3, and bone has a density range of 1700 to 2000 kg/m^3. To find these values I looked them up.

